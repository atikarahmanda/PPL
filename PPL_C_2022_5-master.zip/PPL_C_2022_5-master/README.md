# Sistem Akademik Siswa
## Authors
1. Nurida Larasati
2. Mumtaz Hana
3. Atika Resti
4. Veronika Manalu

## Description
Project ini merupakan project sistem akademik perkuliahan

## Preview
login page
![Web capture_25-12-2022_11280_localhost](https://user-images.githubusercontent.com/89529910/209456954-f828e10b-9e7b-4dc0-8b26-1dfd51d084e6.jpeg)

dashboard page
![Web capture_25-12-2022_112619_localhost](https://user-images.githubusercontent.com/89529910/209456932-c263655b-2920-4c83-ac6f-2e8416bdba47.jpeg)
