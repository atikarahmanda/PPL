<div class="navMenu">
        <a href="srs2.php?id=' . $row->ID.'" class="">PROFIL</a>&nbsp;&nbsp;
        <a href="srs3.php?id=' . $row->ID.'" class="">IRS</a>&nbsp;&nbsp;
        <a href="srs4.php?id=' . $row->ID.'" class="">KHS</a>&nbsp;&nbsp;
        <a href="srs5.php?id=' . $row->ID.'" class="">PKL</a>&nbsp;&nbsp;
        <a href="srs6.php?id=' . $row->ID.'" class="">SKRIPSI</a>&nbsp;&nbsp;
</div>
<!-- <script src="https://code.jquery.com/jquery-3.3.1.js"></script>
<script type="text/javascript">
      $(document).on('click','a',function(){
            $(this).addClass('active').siblings().removeClass('active')
      })
</script> -->
<!-- <script src="javascript.js"></script> -->