// navbar = document.querySelector(".navMenu").querySelectorAll("a");
// console.log(navbar);

// navbar.forEach(element => {
//     element.addEventListener("click", function(){
//         navbar.forEach(nav => nav.classList.remove("active"))
        
//         this.classList.add("active");
//     })
// });

// // Get the container element
// var btnContainer = document.getElementsByClassName("navMenu");

// // Get all buttons with class="btn" inside the container
// var btns = btnContainer.getElementsByTagName("a");

// // Loop through the buttons and add the active class to the current/clicked button
// for (var i = 0; i < btns.length; i++) {
//   btns[i].addEventListener("click", function() {
//     var current = document.getElementsByClassName("active");
//     current[0].className = current[0].className.replace(" active", "");
//     this.className += " active";
//   });
// }